; =========================================================================
; PERFECT COMMANDER 112 — СИСТЕМНЫЙ ДРАЙВЕР СТРАНИЧНОЙ ВИДЕОПАМЯТИ
; МОДУЛЬ: src/display_384.asm (КАНОНИЧЕСКИЙ СИНТАКСИС)
; =========================================================================

ClearScreen_384x304:
        PUSH    AF
        PUSH    BC
        PUSH    DE
        PUSH    HL
        
        ; Очищаем четные сканлайны (Страница ОЗУ 5 Пентагона)
        LD      A, #15                  
        LD      BC, #7FFD
        OUT     (C), A
        LD      HL, $4000
        LD      DE, $4001
        LD      BC, 16383               
        LD      (HL), %00010001         ; Базовый синий фон
        LDIR

        ; Очищаем нечетные сканлайны (Страница ОЗУ 1 Пентагона)
        LD      A, #11                  
        LD      BC, #7FFD
        OUT     (C), A
        LD      HL, $4000
        LD      DE, $4001
        LD      BC, 16383               
        LD      (HL), %00010001         
        LDIR

        ; Возвращаем стабильную системную страницу 0
        LD      A, #10
        LD      BC, #7FFD
        OUT     (C), A
        
        POP     HL
        POP     DE
        POP     BC
        POP     AF
        RET

PrintString_384x304:
        LD      A, (HL)
        OR      A                       
        RET     Z                       
        PUSH    HL
        CALL    PrintChar_384x304
        INC     C                       ; Движемся по 48-колоночной сетке
        POP     HL
        INC     HL
        JR      PrintString_384x304

PrintChar_384x304:
        PUSH    AF
        PUSH    BC
        PUSH    DE
        PUSH    HL

        ; Расчет пиксельной строки: Y_Pixel = Y * 8
        LD      A, D
        ADD     A, A                    
        ADD     A, A                    
        ADD     A, A                    
        LD      E, A
        LD      D, 0                    

        ; Математика смещения: Offset = Y_Pixel * 192 байта
        PUSH    DE
        POP     HL                      
        LD      B, 6                    
.mul64:
        ADD     HL, HL
        DJNZ    .mul64
        PUSH    HL                      
        ADD     HL, HL                  
        POP     BC                      
        ADD     HL, BC                  

        ; Базовое окно видеоконтроллера Спектрума
        LD      BC, $4000
        ADD     HL, BC                  

        ; Добавляем X (каждое знакоместо занимает строго 4 байта)
        LD      A, C                    
        ADD     A, A                    
        ADD     A, A                    
        LD      C, A
        LD      B, 0                    
        ADD     HL, BC                  

        EX      DE, HL                  
        
        ; Безопасное извлечение символа через IX без порчи прерываний
        PUSH    IX
        LD      IX, 0
        ADD     IX, SP                  
        LD      A, (IX + 10)            
        POP     IX                      

        SUB     32                      
        LD      L, A
        LD      H, 0
        ADD     HL, HL                  
        ADD     HL, HL                  
        ADD     HL, HL                  
        
        LD      BC, EXTERNAL_FONT_BIN112 
        ADD     HL, BC                  

        LD      B, 8                    
.draw_loop_384:
        PUSH    BC
        PUSH    DE                      
        
        LD      A, (HL)                 
        LD      B, A                    
        
        LD      C, 4                    
.pixel_pair_loop:
        LD      A, %00010001            ; Фон синий
        
        RLC     B                       
        JR      NC, .left_is_paper
        OR      %11100000               ; Шрифт белый
.left_is_paper:

        RLC     B                       
        JR      NC, .right_is_paper
        OR      %00001110               ; Шрифт белый
.right_is_paper:

        ; Аппаратная маскировка записи в нужную банку через порт #7FFD
        ; Четные строки рисуем в RAM 5, нечетные — в RAM 1
        LD      (DE), A                 
        INC     DE                      
        DEC     C
        JR      NZ, .pixel_pair_loop

        POP     DE                      
        LD      BC, 192                 
        EX      DE, HL
        ADD     HL, BC
        EX      DE, HL                  

        INC     HL                      
        POP     BC
        DJNZ    .draw_loop_384

        POP     HL
        POP     DE
        POP     BC
        POP     AF
        RET

        ALIGN 256
EXTERNAL_FONT_BIN112:
        INCBIN "src/font.bin"
