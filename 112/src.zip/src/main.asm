; =========================================================================
; PERFECT COMMANDER 112 — ПОШАГОВЫЙ ДИАГНОСТИЧЕСКИЙ СТЕНД ИЗОЛЯЦИИ ШАГОВ
; МОДУЛЬ: src/main.asm (ИСПРАВЛЕН РАСЧЕТ РАЗМЕРА БЛОКА ДЛЯ SAVETRD)
; =========================================================================

        DEVICE ZXSPECTRUM128    
        EMPTYTRD "project112.TRD"

        ORG $6000                       ; Старт кода ( RANDOMIZE USR 24576 )

Init_Z80_System112:
        DI                              ; Блокируем маскируемые прерывания
        LD      (Saved_SP_112), SP    
        LD      SP, $FFFE               ; Переносим стек хоста в безопасный верх

        ; =========================================================================
        ; ШАГ 1: ТЕСТ ИНИЦИАЛИЗАЦИИ И СТАНДАРТНОЙ СТРАНИЦЫ #10
        ; =========================================================================
        LD      A, #10                  
        LD      BC, #7FFD
        OUT     (C), A                  ; Открываем базовую Страницу 0 коммандера

        ; Выводим сообщение первого шага через ПЗУ (черный текст)
        LD      HL, Msg_Step1
        CALL    Direct_Print_ROM_Text
        
        ; Ожидаем нажатия Пробела для перехода к Шагу 2
        CALL    Wait_Space_Bar

        ; =========================================================================
        ; ШАГ 2: БЕЗОПАСНАЯ ОЧИСТКА СТАНДАРТНОГО ЭКРАНА В СИНИЙ ЦВЕТ
        ; =========================================================================
        LD      HL, $5800               ; Зона атрибутов стандартного экрана
        LD      DE, $5801
        LD      BC, 767
        LD      (HL), %00001000         ; Синий Paper, Черный Ink, Яркость 0
        LDIR

        ; Выводим сообщение второго шага
        LD      HL, Msg_Step2
        CALL    Direct_Print_ROM_Text

        CALL    Wait_Space_Bar

        ; =========================================================================
        ; ШАГ 3: ВКЛЮЧЕНИЕ АППАРАТНОГО РЕЖИМА 384x304 (ВРЕЗКА ПОРТА #EFF7)
        ; Если UnrealSpeccy падает ТУТ — проблема в конфигурации Unreal.ini (EFF7 lock)
        ; =========================================================================
        LD      A, #40                  ; Бит 6 отвечает за экран 384х304
        LD      BC, #EFF7
        OUT     (C), A                  ; Аппаратное переключение видеорежима эмулятора

        ; Выводим сообщение третьего шага
        LD      HL, Msg_Step3
        CALL    Direct_Print_ROM_Text

        CALL    Wait_Space_Bar

        ; =========================================================================
        ; ШАГ 4: ФИНАЛЬНЫЙ ТЕСТ ПЕРЕКЛЮЧЕНИЯ СТРАНИЦ ОЗУ 5 И ОЗУ 1
        ; =========================================================================
        LD      A, #15                  ; Включаем RAM 5
        LD      BC, #7FFD
        OUT     (C), A

        LD      HL, $C000
        LD      DE, $C001
        LD      BC, 100
        LD      (HL), %01110111         ; Проверочный паттерн пикселей
        LDIR

        LD      A, #10                  ; Возвращаем RAM 0
        LD      BC, #7FFD
        OUT     (C), A

        LD      HL, Msg_Step4
        CALL    Direct_Print_ROM_Text

FinalLoop:
        JR      FinalLoop

; --- ПОДПРОГРАММА ПРЯМОГО ВЫВОДА СИМВОЛОВ ИЗ ПЗУ (БЕЗ ИСПОЛЬЗОВАНИЯ СТЕКА x86) ---
Direct_Print_ROM_Text:
        PUSH    AF
        PUSH    BC
        PUSH    DE
        PUSH    HL
.char_loop:
        LD      A, (HL)
        OR      A
        JR      Z, .text_done
        
        ; Вызываем печать символа через ПЗУ Spectrum (Вектор #10)
        ; Чтобы не ломать регистры, пишем символ напрямую в системный буфер принтера ПЗУ
        PUSH    HL
        LD      IY, #5C3A               ; Восстанавливаем системный IY для ПЗУ Спектрума
        
        ; Прямой вывод на экран хоста через RST 16
        db      #D7                     ; Опкод RST 16 (Официальный принтер ПЗУ)
        
        POP     HL
        INC     HL
        JR      .char_loop
.text_done:
        POP     HL
        POP     DE
        POP     BC
        POP     AF
        RET

; --- АВТОНОМНЫЙ АППАРАТНЫЙ ОПРОС КЛАВИАТУРЫ (КЛАВИША ПРОБЕЛ) ---
Wait_Space_Bar:
        PUSH    AF
        PUSH    BC
.space_loop:
        ; Опрашиваем полуряд ПРОБЕЛ, СИМВОЛ, M, N, B (Порт #7FFE)
        LD      BC, #7FFE
        IN      A, (C)
        BIT     0, A                    ; Бит 0 отвечает строго за Пробел
        JR      NZ, .space_loop         ; Крутимся, пока Пробел НЕ нажат

.space_release:
        ; Ждем физического отпускания Пробела, чтобы не проскочить шаги от дребезга
        IN      A, (C)
        BIT     0, A
        JR      Z, .space_release
        
        POP     BC
        POP     AF
        RET

Saved_SP_112:   DW 0

Msg_Step1:      DEFM "STEP 1: REGS INITIALIZED OK. PUSH SPACE TO CLEAR SCREEN...", #0D, 0
Msg_Step2:      DEFM "STEP 2: BLUE SCREEN OK. PUSH SPACE TO ACTIVATE EFF7 384x304...", #0D, 0
Msg_Step3:      DEFM "STEP 3: HARDWARE VIDEO MODE SWITCHED OK. PUSH SPACE FOR PAGES TEST...", #0D, 0
Msg_Step4:      DEFM "STEP 4: ALL HARDWARE STEPS VERIFIED PASSED. SYSTEM STABLE.", #0D, 0

ProgramEnd112:                          ; Глобальная метка конца исполняемого кода хоста

; =========================================================================
; ГЕНЕРАЦИЯ СТАНДАРТНОГО БЕЙСИК-ЗАГРУЗЧИКА (БЕЗ СДВИГОВ И ДВОЕТОЧИЙ)
; =========================================================================
        ORG $B000
CLEAR       EQU $FD
RANDOMIZE   EQU $F9
USR         EQU $C0
REM         EQU $EA

basic_loader:
        DB      0, 10
        DW      l10_len
l10:
        DB      CLEAR, "24575", $0E, 0, 0
        DW      24575
        DB      0, $0D
l10_len EQU     $-l10

        DB      0, 20
        DW      l20_len
l20:
        DB      RANDOMIZE, USR, "15619", $0E, 0, 0
        DW      15619
        DB      0
        DB      $3A, REM, $3A
        DB      "LOAD ", 34, "proj112", 34, " CODE 24576", $0D
l20_len EQU     $-l20

        DB      0, 30
        DW l30_len
l30:
        DB      RANDOMIZE, USR, "24576", $0E, 0, 0
        DW      24576
        DB      0, $0D
l30_len EQU     $-l30
basic_loader_end:              

        ; ИСПРАВЛЕНО: Расчет длины бинарного блока заменен глобальной меткой ProgramEnd112
        SAVETRD "project112.TRD", "proj112.B", basic_loader, basic_loader_end - basic_loader, 10
        SAVETRD "project112.TRD", "proj112.C", $6000, ProgramEnd112 - $6000
